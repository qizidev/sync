vcmv = {};

vcmv.isFirstLoad = function(namesp) {
  var isFirst = namesp.firstLoad === undefined;
  namesp.firstLoad = false;
  return isFirst;
}

window.onload = function() {
  if (!vcmv.isFirstLoad(vcmv)) {
	  return;
  }
  var aaus = document.querySelectorAll("a.audio");
  for (let i = 0; i < aaus.length; i++) {
    var aau = aaus[i];
    aau.addEventListener("click", playAudio);
  }
}

function playAudio() {
  var audio = this.nextElementSibling;
  audio.play();
}
